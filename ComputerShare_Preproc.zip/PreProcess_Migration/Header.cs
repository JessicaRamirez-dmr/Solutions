﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class Header
    {
        //Record type 10 - Code 1
        public string HolderID { get; set; }
        public string HolderRecType { get; set; }
        public string HolderRecSubType { get; set; }

        public string HolderStmtType { get; set; }
        public string HolderLongName { get; set; }
        public string HolderBranchCode { get; set; }
        public string HolderStmtNo { get; set; }
        public string HolderStmtReason{ get; set; }
        public string HolderEmailAdd { get; set; }
        public string HolderOutStream { get; set; }
        public string HolderInvTradeSellFlag { get; set; }

        //Record type 10 - Code 2
        public string HolderMailName { get; set; }   
        public string HolderAlphaKey { get; set; }
        public string HolderIDType { get; set; } //CSN, HIN, SRN 
        public string HolderIDTypeNo { get; set; } //CSN, HIN, SRN  number
        
        //Record type 10 - Code 3
        public string HolderAdd1 { get; set; }
        public string HolderAdd2 { get; set; }
        public string HolderAdd3 { get; set; }
        public string HolderAdd4 { get; set; }
        public string HolderAdd5 { get; set; }
        public string HolderAdd6 { get; set; }
        public string HolderAdd7 { get; set; }
        public string HolderAdd8 { get; set; }
        public string HolderAdd9 { get; set; }
        public string HolderAdd10 { get; set; }
        public string HolderCountryCode { get; set; }
        public string HolderPcode { get; set; }
        public string HolderGNA { get; set; }
        
   }

    /*Index sequence from Header section 
  * Index, Field Name, example value

  */
}
