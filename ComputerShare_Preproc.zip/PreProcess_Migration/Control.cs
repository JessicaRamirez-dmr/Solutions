﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class Control
    {
        public string CntrlHeaderID { get; set; }
        public string CntrlHeaderRecType { get; set; }
        public string CntrlHeaderTitle { get; set; }
        public string CntrlHeaderDateFrom { get; set; }
        public string CntrlHeaderDateTo { get; set; }
        public string CntrlHeaderComments { get; set; }
        public string CntrlHeaderFiller { get; set; }
    }

  /*Index sequence from Control data file
* Index, Field Name, example value

*/
}
