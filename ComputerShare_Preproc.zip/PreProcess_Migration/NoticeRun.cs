﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class NoticeRun
    {
        public string JobBag;
        public string RunNo;
    }
}
