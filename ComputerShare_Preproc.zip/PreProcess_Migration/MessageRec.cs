﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class MessageRec
    {
        //Record type 30- Code 1
        public string MsglID { get; set; }
        public string MsgRecType { get; set; }
        public string MsgNoticeCode { get; set; }
        public string MsgNoticeType{ get; set; }
        public string MsgNotice{ get; set; }

    }
}
