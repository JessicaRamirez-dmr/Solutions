﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class Payment
    {
        public string RefID { get; set; }
        public string RecordNo { get; set; }
        public string ContractNo { get; set; }
        public string Issuer { get; set; }
        public string HoldingPrincipal { get; set; }
        public string PaymentRate { get; set; }
        public string Consideration { get; set; }
        public string PaymentFee { get; set; }
        public string PaymentAmt { get; set; }
        public string CurrencyCode { get; set; }
       
    }
    /*Index sequence from Payment data file
  * Index, Field Name, example value

  */
}
