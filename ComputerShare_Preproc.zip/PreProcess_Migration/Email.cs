﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace FasterTransactionStmt
{
    class Email
    {
               public static void SendEmail(string ToAddresses, string Subject, string Message)
        {

            SmtpClient SMTP = new SmtpClient(FasterTransactionStmt.Properties.Settings.Default.InternalSMTPServer);
            MailMessage Email = new MailMessage();
            var Tos = ToAddresses.Split(new char[] { ',', ':', ';' });
            foreach (var To in Tos)
            {
                Email.To.Add(To);
            }
            Email.From = new MailAddress("sases@solutiondynamics.com", "SASES");
            Email.Subject = Subject;
            Email.Body = Message;

            SMTP.Send(Email);


        }
        public static void SendEmail(string ToAddresses, string Subject, string Message, string Attach)
        {

            SmtpClient SMTP = new SmtpClient(FasterTransactionStmt.Properties.Settings.Default.InternalSMTPServer);
            MailMessage Email = new MailMessage();
            var Tos = ToAddresses.Split(new char[] { ',', ':', ';' });
            foreach (var To in Tos)
            {
                Email.To.Add(To);
            }
            Email.From = new MailAddress("sases@solutiondynamics.com", "SASES");
            Email.Subject = Subject;
            Email.Body = Message;
            Email.Attachments.Add(new Attachment(Attach));

            SMTP.Send(Email);
            SMTP.Dispose();
        }
    
    }
}
