﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ControlReporting;


namespace FasterTransactionStmt
{
    public partial class Form1 : Form
    {
        string JobNumber = "";
        string RunNumber = "";
        string jobType;
        string[] OZFPrefix  = { "AFI", "AMP",  "MHJ", "ANZ" };
        int OZFPrefixCnt = 4;
        NoticeRun run = new NoticeRun();
        List<string> expLst = new List<string>();
        private ControlReport ControlRep;
        private string sCustName = "";
        private string sJobName = "";
        private string sFileName = "";
        private int recordCnt = 0;
        //private string fileheaderID = "";
        //private string fileRecType = "";
        //private string fileTitle = "";
        //private string fileDateFrom = "";
        //private string fileDateTo = "";
        //private int fileHoldersCnt = 0;
        //private int fileRecordCnt = 0;


        public Form1(string JobNumber, string RunNumber)
        {
            InitializeComponent();
            
        }
        //public Form1(string JobNumber, string RunNumber)
        //{
        //    InitializeComponent();
        //    this.JobNumber = JobNumber;
        //    this.RunNumber = RunNumber;
        //}

     
        private void Form1_Load(object sender, EventArgs e)
        {
            if (this.JobNumber != null && this.RunNumber != null)
                backgroundWorker1.RunWorkerAsync();

        }
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            if (this.JobNumber != null && this.RunNumber != null)
                RunApplication();
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.Close();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            tbJB.Text = tbJB.Text.Trim();
           

            //
            tbRun.Text = tbRun.Text.Trim();

            //

            //
            btnStart.Enabled = true;

            tbJB.Enabled = false;
            tbRun.Enabled = false;

            Application.DoEvents();
            RunApplication();
        }
        private void RunApplication()
        {
            if (tbJB.Text != "" && tbRun.Text != "")
            {
                run.JobBag = tbJB.Text.Trim();
                run.RunNo = tbRun.Text.Trim();
            }
            else
            {
                run.JobBag = this.JobNumber;
                run.RunNo = this.RunNumber;
            }

            sCustName = "CIS";
            if (radioButton1.Checked == true)
            {
                sJobName = "NZF";
                jobType = "NZFaster";
            }
            else  if (radioButton2.Checked == true) 
            {
                sJobName = "OZF";
                jobType = "OZFaster";
             }
  
            string ReceivedDir = Path.Combine(FasterTransactionStmt.Properties.Settings.Default.AppPath , FasterTransactionStmt.Properties.Settings.Default.InpPath);
            string outputPath = Path.Combine(FasterTransactionStmt.Properties.Settings.Default.AppPath , FasterTransactionStmt.Properties.Settings.Default.OutPath);
            
            ControlRep = new ControlReport(sCustName, sJobName, run.JobBag, run.RunNo);
 
            Directory.CreateDirectory(outputPath + run.JobBag + "_" + run.RunNo);

            //CheckEmptyFileSet(ReceivedDir);

            // check the files if they are the expected files for this job
            bool bStatus =  IsValidFile(ReceivedDir); 

            if (expLst.Count == 0)
            {
                var allFiles = Directory.GetFiles(ReceivedDir, "*CIS.STATE.*");//CIS.STATE
                foreach (var fileCtrl in allFiles)
                {
                    string FileName = Path.GetFileNameWithoutExtension(fileCtrl);
                    //string Code = FileName.Substring(0, FileName.IndexOf("CONTROL"));
                    //var DetailFile = Directory.GetFiles(ReceivedDir, Code + "DETAIL.txt");
                   // var PaymentFile = Directory.GetFiles(ReceivedDir, Code + "PAYMENT.txt");
                    List<string> Files = new List<string>();
                   // List<string> Payment = new List<Payment>();
                    Files.Add(fileCtrl);
                    //Files.Add(DetailFile[0]);
                    //Files.Add(PaymentFile[0]);
                    Process(Files);
                    MoveTodone(Files);
                }
            }
            else 
            {
                string excepFilename = outputPath + run.JobBag + "_" + run.RunNo + "\\" + run.JobBag + "_" + run.RunNo +  "_" + "ExceptionReport.txt";

                using (TextWriter tw = new StreamWriter(excepFilename))
                {
                    foreach (String s in expLst)
                        tw.WriteLine(s);
                    tw.Close();
                }
                //send the Exception report via email
                Email.SendEmail(FasterTransactionStmt.Properties.Settings.Default.LiveEmailRecipients, "Exception Reporting", "Process failed to complete in job " + sCustName + " " + sJobName + ", see Exception Report for the details", excepFilename);
            }
        }

        private void MoveTodone(List<string> Files)
        {
            foreach (var file in Files)
            {
                string receivedDone = Path.GetDirectoryName(file) + "\\Done\\" + Path.GetFileName(file);
                if (File.Exists(receivedDone))
                    File.Delete(receivedDone);
                File.Move(file, receivedDone);
            }
        }
        private void MoveExceptionFile(string code, string ReceiviedDir)
        {
            string onHoldPath = FasterTransactionStmt.Properties.Settings.Default.AppPath + FasterTransactionStmt.Properties.Settings.Default.ExceptionHold;
            var DirectoryInfo = new DirectoryInfo(ReceiviedDir);
            var allFiles = DirectoryInfo.GetFiles(code + "*.txt");
            foreach (var file in allFiles)
            {
                string onHoldFile = onHoldPath + "\\" + Path.GetFileName(file.Name);
                if (File.Exists(onHoldFile))
                    File.Delete(onHoldFile);
                File.Move(file.FullName, onHoldFile); 
            }
        }

        private void CheckEmptyFileSet(string ReceiviedDir)          //20170314|JR - added validation rule if control file is empty - move all sets to OnHold folder
        {
            var DirectoryInfo = new DirectoryInfo(ReceiviedDir);
            var allControlFiles = DirectoryInfo.GetFiles("*CONTROL.txt");
            foreach (FileInfo fileCtrl in allControlFiles)
            {
                string Code = fileCtrl.Name.Substring(0, fileCtrl.Name.IndexOf("CONTROL"));
                
                var controlName = File.ReadAllLines(fileCtrl.FullName);
                if (controlName.Length == 0)
                {
                    expLst.Add("Empty Control file found for Client Code " + Code.Substring(0, 3) + " Event Number " + Code.Substring(3, (Code.Length - 3)));
                    MoveExceptionFile(Code, ReceiviedDir);
                }
            }
        }

        private bool IsValidFile(string ReceivedDir)
        {
            bool isStatus = true;
            var DirectoryInfo = new DirectoryInfo(ReceivedDir);
             
            switch (jobType)
            {
                case "NZFaster":
                    var allNZFfiles = DirectoryInfo.GetFiles("CIS.STATE*");
                    if (allNZFfiles.Length == 0)
                    {
                        isStatus = false;
                    }
                    else
                    {
                        foreach (FileInfo file in allNZFfiles)
                        {
                            var sLine = File.ReadAllLines(file.FullName);
                            if (sLine[0].Contains("TRANSACTION STATEMENT") == false) isStatus = false;
                            else isStatus = true;
                        }
                    }
                    break;
                case "OZFaster":
                    var allOZFfiles = DirectoryInfo.GetFiles("*.STATE*");
                    if (allOZFfiles.Length == 0)
                    {
                        isStatus = false;
                    }
                    else
                    {
                        foreach (FileInfo file in allOZFfiles)
                        {
                            var sLine = File.ReadAllLines(file.FullName);
                            int strIndex = 0;
                            for (int arrayNum = 0; arrayNum < OZFPrefixCnt+1 ; arrayNum++)
			                        {
			                          strIndex =  OZFPrefix[arrayNum].IndexOf(sLine[0].Substring(2,3).ToString());
                                      if (strIndex < 0)
                                      {
                                          isStatus = false;
                                          continue;
                                      }
                                      else
                                      {
                                          isStatus = true;
                                         break ;
                                      }
  
			                        }
                        }
                    }

                    break;
                default:
                 break;
            }
  
            return isStatus;
        }

        private bool ValidateFile(Dictionary<string, string> controlDict, string[] split)
        {
            bool isstatus = true;
            foreach (var key in controlDict)
            {
                switch (key.Key.ToString())
                {
                    case "ClientCode":
                        string detailClientCode = split[0];
                        if (!key.Value.Equals(detailClientCode))
                        {
                            isstatus = false;
                        }
                        break;
                    case "EventNo":
                        string detailEventNo = split[1];
                        if (!key.Value.Equals(detailEventNo))
                        {
                            isstatus = false;
                        }
                        break;
                    case "RemEventNo":
                        string detailRemEventNo = split[2];
                        if (!key.Value.Equals(detailRemEventNo))
                        {
                            isstatus = false;
                        }
                        break;
                    case "FileTye":
                        string detailFileTye = split[3];
                        if (!key.Value.Equals(detailFileTye))
                        {
                            isstatus = false;
                        }
                        break;
                    case "FormCode":
                        string detailFormCode = split[4];
                        if (!key.Value.Equals(detailFormCode))
                        {
                            isstatus = false;
                        }
                        break;
                    //case "ReferenceID":
                    //    string detailReferenceID = split[6];
                    //    if (!key.Value.Equals(detailReferenceID))
                    //    {
                    //        isstatus = false;
                    //    }
                    //    break;
                }

            }
            return isstatus;
        }
        private void Process(List<string> Files)
        {
            
            string outputPath = Path.Combine(FasterTransactionStmt.Properties.Settings.Default.AppPath,  FasterTransactionStmt.Properties.Settings.Default.OutPath);
            var ctrl = new Control();
            var lstHeader = new List<Header>();
            var lstdetail = new List<Detail>();
            var lstPayments = new List<Payment>();
            recordCnt = 0;
            foreach (var file in Files)
            {
                if (Path.GetFileNameWithoutExtension(file).ToUpper().EndsWith("CIS.STATE"))
                {
                    sFileName = Path.GetFileNameWithoutExtension(file).ToUpper();
                    //var lstStemp = ReadData(file, 54);
                    StreamReader sr = new StreamReader(file);
                    String sTemp = "";
                    while ((sTemp = sr.ReadLine()) != null)
                    {
                        sTemp = sTemp.PadRight(1000);
                        var header = new Header();
                        var detail = new Detail();
                        if (sTemp.Substring(9, 2) == "00")
                        {
                            //fileHeader
                            ctrl.CntrlHeaderDateFrom = sTemp.Substring(40, 8);
                            ctrl.CntrlHeaderDateTo = sTemp.Substring(48, 8);
                        }

                        if (sTemp.Substring(9, 3) == "101")
                        {
                            Int32 stmtno = 0;
                            //Record Header in type 1
                            header.HolderID = sTemp.Substring(0, 9);
                            header.HolderStmtType = sTemp.Substring(12, 1);
                            header.HolderLongName = sTemp.Substring(13, 150);
                            header.HolderBranchCode = sTemp.Substring(162, 2);
                            if (header.HolderBranchCode.ToUpper() == "NZ") header.HolderBranchCode = "NEW ZEALAND";
                            header.HolderStmtNo = sTemp.Substring(165, 7);
                            if (Int32.TryParse(header.HolderStmtNo, out stmtno)) stmtno.ToString();
                            header.HolderOutStream = sTemp.Substring(173, 60);
                            header.HolderEmailAdd = sTemp.Substring(233, 1);
                            
                            header.HolderInvTradeSellFlag = sTemp.Substring(234, 1).ToUpper();
                        }

                        if (sTemp.Substring(9, 3) == "102")
                        {
                            //Record Header in type 2
                            header.HolderMailName = sTemp.Substring(12, 40);
                            header.HolderAlphaKey = sTemp.Substring(12, 1);
                            header.HolderIDType = sTemp.Substring(63, 150);
                            header.HolderBranchCode = sTemp.Substring(162, 2);
                            if (header.HolderBranchCode.ToUpper() == "NZ") header.HolderBranchCode = "NEW ZEALAND";
                            header.HolderStmtNo = sTemp.Substring(165, 7);
                        }

                        if (sTemp.Substring(9, 3) == "103")
                        {
                            //Record Header in type 2
                            header.HolderAdd1 = sTemp.Substring(12, 41);
                            header.HolderAdd2 = sTemp.Substring(53, 41 );
                            header.HolderAdd3 = sTemp.Substring(94, 41);
                            header.HolderAdd4 = sTemp.Substring(135, 41);
                            header.HolderAdd5 = sTemp.Substring(176, 41);
                            header.HolderAdd6 = sTemp.Substring(217, 41);
                            header.HolderAdd7 = sTemp.Substring(258, 41);
                            header.HolderAdd8 = sTemp.Substring(299, 41);
                            header.HolderAdd9 = sTemp.Substring(340, 41);
                            header.HolderAdd10 = sTemp.Substring(381, 41);
                            header.HolderCountryCode =  sTemp.Substring(422, 2);
                            header.HolderPcode = sTemp.Substring(424, 10);
                            header.HolderGNA = sTemp.Substring(434, 1);
                        }

                        if (sTemp.Substring(9, 3) == "20")
                        {
                            //Record Detail in type 2
                            detail.DetlSecuCode = sTemp.Substring(12, 12);
                            detail.DetlRecSubType = sTemp.Substring(24, 1);
                            detail.DetlPrintIND = sTemp.Substring(25, 1);
                            detail.DetlRegQty = sTemp.Substring(26, 13);

                        }




                    }
                    sr.Close();
                }
             }
            
            //foreach (var detail in lstdetail)
            //{
            //    var payments = lstPayments.Where(x => x.RefID.Equals(detail.RefID)).OrderBy(x => x.RecordNo).ToList<Payment>();
            //    detail.PaymentLst = payments;
                
            //}

            if (ctrl != null)
            {
                ControlRep.AddInputCount(sFileName, ControlReport.InputFile.FileType.Data, recordCnt, recordCnt, 0);
                string sArchiveName = outputPath + run.JobBag + "_" + run.RunNo + "\\" + sJobName + ".dta";
                //DumpFile(sArchiveName, lstdetail, run.JobBag, run.RunNo);

                ControlRep.OutputReport(Path.Combine(outputPath + run.JobBag + "_" + run.RunNo, run.JobBag + "_" + run.RunNo + "_" + sJobName + "_Report.txt"));
                

            } 
        }

        //private void DumpFile(String sFileName, List<Detail> lst,string jobNumber, string runNumber)
        //{
        //    StreamWriter sw = new StreamWriter(sFileName);
        //    var spliFileName = Path.GetFileNameWithoutExtension(sFileName).Split('_');

        //    sw.WriteLine("FILES" + MakeField(jobNumber, 5) + MakeField(runNumber, 4) + MakeField(spliFileName[4], 20) );
        //    foreach (Detail l in lst)
        //    {
                
        //        sw.WriteLine("SETB" + MakeField(l.HolderNumber, 40) + MakeField(l.MailingName, 100) + MakeField(l.AddressLine1, 100) + MakeField(l.AddressLine2, 100) + MakeField(l.AddressLine3, 100) + MakeField(l.AddressLine4, 100) + MakeField(l.AddressLine5, 100) + MakeField(l.AddressLine6, 100) + MakeField(l.AddressLine7, 100));
        //        sw.WriteLine("DOCB" + MakeField(l.HolderNumber, 40));
        //        //20170315 | JR added the control currency to export
        //        //sw.WriteLine("CTRL" + MakeField(l.control.SaleDate.ToString("dd/MM/yyyy"), 10) + MakeField(l.control.SettlementDate.ToString("dd/MM/yyyy"), 10) + MakeField(l.control.ClientName, 120) + MakeField(l.control.CurrencyMsg1, 200) + MakeField(l.control.CurrencyMsg2, 200) + MakeField(l.control.CurrencyMsg3, 200)+ MakeField(l.control.DSSSystem, 12));
        //       sw.WriteLine("CTRL" + MakeField(l.control.SaleDate.ToString("dd/MM/yyyy"), 10) + MakeField(l.control.SettlementDate.ToString("dd/MM/yyyy"), 10) + MakeField(l.control.ClientName, 120) + MakeField(l.control.CurrencyMsg1, 200) + MakeField(l.control.CurrencyMsg2, 200) + MakeField(l.control.CurrencyMsg3, 200)+ MakeField(l.control.DSSSystem, 12)+MakeField(l.control.CntlCurrency,3));
        //        //20170222- JR replaced PayeeCSN to ----> CISHolderNo 
        //        //sw.WriteLine("DETL" + MakeField(l.FullName, 100) + MakeField(l.HolderNumber, 40) + MakeField(l.RemittanceAmount, 15) + MakeField(l.MandateMsg1, 100) + MakeField(l.MandateMsg2, 100) + MakeField(l.MandateMsg3, 100) + MakeField(l.CSN, 10) + MakeField(l.HoldingMailingName, 50));
        //       sw.WriteLine("DETL" + MakeField(l.FullName, 100) + MakeField(l.HolderNumber, 40) + MakeField(l.RemittanceAmount, 15) + MakeField(l.MandateMsg1, 100) + MakeField(l.MandateMsg2, 100) + MakeField(l.MandateMsg3, 100) + MakeField(l.CISHolderNo, 10) + MakeField(l.HoldingMailingName, 50) + MakeField(l.NetProceedsAmt, 15));
        //        //end
        //        sw.Write(BuildPayment(l.PaymentLst));
        //        sw.WriteLine("DOCE");
        //        sw.WriteLine("SETE");
                
        //    }
        //    sw.Close();
        //     ControlRep.AddFreeLine("");
        //}

        private string BuildPayment(List<Payment> lstPayment)
        {
            var sb = new StringBuilder();
            foreach (Payment pymt in lstPayment)
            {
                string Payment = "PYMT" + MakeField(pymt.ContractNo, 10) + MakeField(pymt.Issuer, 120) + MakeField(pymt.HoldingPrincipal, 10) + MakeField(pymt.PaymentRate, 10) + MakeField(pymt.Consideration, 10) + MakeField(pymt.PaymentFee, 10) + MakeField(pymt.PaymentAmt, 15) + MakeField(pymt.CurrencyCode, 3);
                sb.AppendLine(Payment);
            }
            return sb.ToString();
        }

        private String MakeField(Object o, int len) // Converts content of object "o" to a string of length "len"
        {
            return o.ToString().Trim().PadRight(len).Substring(0, len);
        }
        private List<string[]> ReadData(string fileName, int numberOfColumns)
        {
            var lstStemp = new List<string[]>();
            var sLine = "";
            var sr = new StreamReader(fileName);
            sr.ReadLine();// skipping the header part 
            while ((sLine = sr.ReadLine()) != null)
            {
                String[] sTemp = new String[numberOfColumns];
                string sTestLine = sLine;

                if (sTestLine.Trim().Length > 0)
                {
                    for (int ii = 0; ii < numberOfColumns; ii++) sTemp[ii] = "";
                    int nCurrField = 0;
                    bool bQuoted = false;
                    for (int i = 0; nCurrField < numberOfColumns && i < sLine.Length; i++)
                    {
                        char c = sLine.ToCharArray()[i];
                        switch (c)
                        {
                            case ('"'):
                                bQuoted = !bQuoted;
                                break;
                            case ('|'):
                                if (!bQuoted)
                                {
                                    nCurrField++;
                                }
                                else
                                {
                                    sTemp[nCurrField] += c;
                                }
                                break;
                            default:
                                sTemp[nCurrField] += c;
                                break;
                        }
                    }
                }
                lstStemp.Add(sTemp);
            }
            sr.Close();
            return lstStemp;

        }
    }
}
