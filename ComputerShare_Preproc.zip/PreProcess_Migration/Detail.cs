﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FasterTransactionStmt
{
    public class Detail
    {
        //Record type 20- Code 1
        public string DetlID { get; set; }
        public string DetlRecType { get; set; }
        public string DetlSecuCode { get; set; }
        public string DetlRecSubType { get; set; }

        public string DetlPrintIND { get; set; }
        public string DetlRegQty { get; set; }
        public string DetlUnavailQty{ get; set; }
        public string DetlClientCode { get; set; }
        public string DetlClassCode { get; set; }
        public string DetlClassName { get; set; }
        public string DetlClientName { get; set; }

        //Record type 20- Code 2
        public string DeltTransferDate { get; set; }
        public string DetlTransferType { get; set; }
        public string DetlContractNo { get; set; }
        public string DetlTransferQty { get; set; }
        public string DetlTransferTypeDesc { get; set; }
        public string DetlTransferSysNo { get; set; }
        public string DetlBrokerCode{ get; set; }
        public string DetlConsideration { get; set; }
        public string DetlOtherParty { get; set; }
        public string DetlOthPartyID { get; set; }
        public string DetlOthPartyRef { get; set; }

        public List<Payment> PaymentLst { get; set; }

    }

    /*Index sequence from Detail section 
     * Index, Field Name, example value
 
    */
}
